library(dplyr)
library(tidyr)
# install.packages('fixest')
library(fixest)
# install.packages('lubridate')
library(lubridate)
# install.packages('ks')
library(ks)

#######

temperature_states <- readRDS('temperature_states.Rds')

region_state_counts <-
  temperature_states %>%
  group_by(region) %>%
  summarise(unique_states = n_distinct(state))

temperature_states <- temperature_states %>%
  mutate(region = case_when(region == 1 ~ 'North',
                            region == 2 ~ 'Northeast',
                            region == 3 ~ 'Southeast',
                            region == 4 ~ 'South',
                            region == 5 ~ 'Central West' ))

#######

nat <-
temperature_states %>%
  group_by(date) %>%
  summarise_at(vars(mean_tmax), list(avg_mean_tmax = mean)) 
doom_nat <-
  nat %>%
  filter(avg_mean_tmax > 32)
print(sprintf('temp > 32 for %s days', nrow(doom_nat)))

reg_nat <- 
  doom_nat %>%
  mutate(year=sapply(date, year)) %>%
  mutate(month=sapply(date, month))

feols(avg_mean_tmax ~ year | month, data=reg_nat)

#######
  
by_region <-
  temperature_states %>%
  group_by(region, date) %>%
  summarise_at(vars(mean_tmax), list(avg_mean_tmax = mean)) 
doom_by_region <-
  by_region %>%
  filter(avg_mean_tmax > 32)
print(doom_by_region %>% group_map(~nrow(.x)))

reg_by_region <-
  doom_by_region %>%
  ungroup() %>%
  mutate(year=sapply(date, year)) %>%
  mutate(month=sapply(date, month)) %>%
  group_by(region)

reg_by_region %>% group_map(~feols(avg_mean_tmax ~ year | month, data=.x))

#####################

pmps <- #per month per state
  temperature_states %>%
  group_by(month, state) %>%
  summarise_at(vars(mean_tmax), list(avg_mean_tmax = mean))

old_nat_mean <-
  temperature_states %>%
  filter(date > '2001-01-01' & date < '2004-12-31') %>%
  group_by(month, state) %>%
  summarise_at(vars(mean_tmax), list(avg_mean_tmax = mean))
# Estimate the KDE
old_kde_result <- density(old_nat_mean$avg_mean_tmax, bw = 2, kernel = "gaussian")

new_nat_mean <-
  temperature_states %>%
  filter(date > '2018-01-01' & date < '2021-12-31') %>%
  group_by(month, state) %>%
  summarise_at(vars(mean_tmax), list(avg_mean_tmax = mean))
# Estimate the KDE
new_kde_result <- density(new_nat_mean$avg_mean_tmax, bw = 2, kernel = "gaussian")


# Plot the first KDE
plot(old_kde_result, main = "Overlapping KDEs for mean_tmax", xlab = "mean_tmax", ylab = "Density", col = "blue")

# Add the second KDE on top of the first one
lines(new_kde_result, col = "red")

# Add a legend to differentiate the two periods
legend("topright", legend = c("Period 1", "Period 2"), col = c("blue", "red"), lty = 1)

#####################

pypmps <- #per month per state
  temperature_states %>%
  group_by(year, month, state) %>%
  summarise_at(vars(mean_tmax), list(avg_mean_tmax = mean)) %>%
  arrange(state, year, month)

pypmps

# Extract year from date column (assuming your date column is 'date')
temperature_states$Year <- as.numeric(format(temperature_states$date, "%Y"))

install.packages("np")
library(np)

# Define a list of regions
regions <- c(1:5)

# Loop through each region and estimate the local constant regression
for (region in regions) {
  # Filter data for the current region
  region_data <- subset(temperature_states, region == region)
  
  # Run the local constant regression (npreg with default Gaussian kernel)
  # Assuming your temperature variable is 'avg_temp' and year is 'Year'
  model <- npreg(mean_tmax ~ year, data = region_data)
  
  # Plot the results
  plot(model, main = paste("Local Constant Regression for", region),
       xlab = "Year", ylab = "Average Temperature", type = "l")
}


